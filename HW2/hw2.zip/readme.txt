To run my program:

$ make
$ ./hw2 data1.txt


data1.txt is the name of the input file that you wish to use. I have included one in this zip file named data1.txt as an example.


If you do not include a text file, and instead only input “$ ./hw1”, it WILL Seg Fault.



Patrick Anderson psa5dg